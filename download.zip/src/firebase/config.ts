export const firebaseConfig = {
  "projectId": "studio-3708607133-5f8b1",
  "appId": "1:769818367049:web:8b7fe4c92d444ea1dd1b98",
  "apiKey": "AIzaSyAjJ5djGZbZltHtImhsP8SqRgqIqfooY5E",
  "authDomain": "studio-3708607133-5f8b1.firebaseapp.com",
  "measurementId": "G-7T9E256N63",
  "messagingSenderId": "769818367049",
  "storageBucket": "studio-3708607133-5f8b1.appspot.com"
};
