
'use client';

import { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ScrollArea } from './ui/scroll-area';
import { Skeleton } from './ui/skeleton';
import { useUser, useFirestore } from '@/firebase';
import { collection, getDocs, orderBy, query } from 'firebase/firestore';
import { format } from 'date-fns';

interface HistoryModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface DailyRecord {
  id: string; // This is the date string YYYY-MM-DD
  date: string;
  studySeconds: number;
}

const formatDuration = (seconds: number) => {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  return `${h}h ${m}m`;
};

// Format YYYY-MM-DD string to a more readable format
const formatDate = (dateString: string) => {
  try {
    const date = new Date(dateString);
    // To account for potential timezone shifts, we add the timezone offset
    const userTimezoneOffset = date.getTimezoneOffset() * 60000;
    const correctedDate = new Date(date.getTime() + userTimezoneOffset);
    return format(correctedDate, 'yyyy年M月d日');
  } catch (e) {
    return dateString; // Fallback to original string if parsing fails
  }
};


export function HistoryModal({ open, onOpenChange }: HistoryModalProps) {
  const { user } = useUser();
  const firestore = useFirestore();
  const [records, setRecords] = useState<DailyRecord[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchRecords = async () => {
      if (user && open && firestore) {
        setLoading(true);
        try {
          const recordsRef = collection(firestore, 'users', user.uid, 'dailyRecords');
          // Order by the 'date' field in descending order to get the latest records first.
          const q = query(recordsRef, orderBy('date', 'desc'));
          const querySnapshot = await getDocs(q);
          const fetchedRecords: DailyRecord[] = [];
          querySnapshot.forEach((doc) => {
            fetchedRecords.push({ id: doc.id, ...doc.data() } as DailyRecord);
          });
          setRecords(fetchedRecords);
        } catch (error) {
          console.error("Error fetching daily records:", error);
        } finally {
          setLoading(false);
        }
      }
    };

    fetchRecords();
  }, [user, open, firestore]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>集中履歴</DialogTitle>
          <DialogDescription>毎日の集中セッションを確認できます。</DialogDescription>
        </DialogHeader>
        <div className="py-4">
          <ScrollArea className="h-72">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>日付</TableHead>
                  <TableHead className="text-right">集中時間</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={i}>
                      <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                      <TableCell className="text-right"><Skeleton className="h-4 w-16 ml-auto" /></TableCell>
                    </TableRow>
                  ))
                ) : records.length > 0 ? (
                  records.map((record) => (
                    <TableRow key={record.id}>
                      <TableCell className="font-medium">{formatDate(record.date)}</TableCell>
                      <TableCell className="text-right">{formatDuration(record.studySeconds)}</TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={2} className="h-24 text-center">
                      記録がありません。集中セッションを完了して履歴を開始しましょう！
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </ScrollArea>
        </div>
      </DialogContent>
    </Dialog>
  );
}
