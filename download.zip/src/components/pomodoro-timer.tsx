
'use client';

import { useState, useEffect, useMemo, useCallback } from 'react';
import { useUser, useFirestore, useMemoFirebase } from '@/firebase';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Timer as TimerIcon, Play, Pause, History, Star } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { doc, getDoc, increment, serverTimestamp, setDoc, updateDoc } from 'firebase/firestore';
import { HistoryModal } from './history-modal';
import { Skeleton } from './ui/skeleton';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';

const STUDY_TIME = 25 * 60; // 25 minutes
const BREAK_TIME = 5 * 60; // 5 minutes
const POINT_INCREMENT_INTERVAL = 30; // 30 seconds

const formatTime = (totalSeconds: number) => {
  const minutes = String(Math.floor(totalSeconds / 60)).padStart(2, '0');
  const seconds = String(totalSeconds % 60).padStart(2, '0');
  return `${minutes}:${seconds}`;
};

const getDateString = (date = new Date()) => {
  return date.toISOString().split('T')[0]; // YYYY-MM-DD
};

const formatDuration = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    return `${h}h ${m}m`;
};

export default function PomodoroTimer() {
  const { user } = useUser();
  const firestore = useFirestore();
  const { toast } = useToast();

  const [mode, setMode] = useState<'study' | 'break'>('study');
  const [isRunning, setIsRunning] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(STUDY_TIME);
  const [sessionSeconds, setSessionSeconds] = useState(0);

  const [totalPoints, setTotalPoints] = useState(0);
  const [dailySeconds, setDailySeconds] = useState(0);
  
  const [isLoading, setIsLoading] = useState(true);
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false);

  const maxSeconds = useMemo(() => (mode === 'study' ? STUDY_TIME : BREAK_TIME), [mode]);
  const progress = useMemo(() => secondsLeft / maxSeconds, [secondsLeft, maxSeconds]);
  
  const CIRCLE_RADIUS = 90;
  const CIRCLE_CIRCUMFERENCE = 2 * Math.PI * CIRCLE_RADIUS;

  const userDocRef = useMemoFirebase(() => {
    if (!user || !firestore) return null;
    return doc(firestore, 'users', user.uid);
  }, [user, firestore]);

  const dailyRecordRef = useMemoFirebase(() => {
    if (!user || !firestore) return null;
    const today = getDateString();
    return doc(firestore, 'users', user.uid, 'dailyRecords', today);
  }, [user, firestore]);

  const fetchUserData = useCallback(async () => {
    if (!user || !userDocRef || !dailyRecordRef) {
      setIsLoading(false);
      return;
    };
    try {
      const userDocSnap = await getDoc(userDocRef).catch(error => {
        errorEmitter.emit('permission-error', new FirestorePermissionError({ path: userDocRef.path, operation: 'get' }));
        throw error;
      });

      if (userDocSnap && userDocSnap.exists()) {
        setTotalPoints(userDocSnap.data().totalPoints || 0);
      } else if (userDocRef) {
        const newUser = { totalPoints: 0, email: user.email, googleId: user.uid };
        setDoc(userDocRef, newUser, { merge: true }).catch(error => {
            errorEmitter.emit('permission-error', new FirestorePermissionError({ path: userDocRef.path, operation: 'create', requestResourceData: newUser }));
        });
        setTotalPoints(0);
      }

      const dailyDocSnap = await getDoc(dailyRecordRef).catch(error => {
        errorEmitter.emit('permission-error', new FirestorePermissionError({ path: dailyRecordRef.path, operation: 'get' }));
        throw error;
      });

      if (dailyDocSnap && dailyDocSnap.exists()) {
        setDailySeconds(dailyDocSnap.data().studySeconds || 0);
      } else {
        setDailySeconds(0);
      }
    } catch (error) {
      // Errors are now emitted, no need to console.error here
    } finally {
      setIsLoading(false);
    }
  }, [user, userDocRef, dailyRecordRef]);

  useEffect(() => {
    setIsLoading(true);
    if (user) {
      fetchUserData();
    } else {
      setTotalPoints(0);
      setDailySeconds(0);
      setSessionSeconds(0);
      setIsLoading(false);
      if (isRunning) {
        setIsRunning(false);
        setSecondsLeft(STUDY_TIME);
        setMode('study');
      }
    }
  }, [user, fetchUserData]); // fetchUserData is stable, so this runs mainly on user change
  
  const saveRecord = useCallback(() => {
    if (!user || !firestore || !dailyRecordRef || !userDocRef || sessionSeconds <= 0) return;
    
    const pointsGained = Math.floor(sessionSeconds / POINT_INCREMENT_INTERVAL) * (10 + Math.floor(sessionSeconds / POINT_INCREMENT_INTERVAL));
    
    const dailyData = {
      studySeconds: increment(sessionSeconds),
      date: getDateString(),
      userProfileId: user.uid,
      lastUpdated: serverTimestamp(),
    };
    setDoc(dailyRecordRef, dailyData, { merge: true }).catch(error => {
      errorEmitter.emit(
        'permission-error',
        new FirestorePermissionError({
          path: dailyRecordRef.path,
          operation: 'update',
          requestResourceData: dailyData,
        })
      )
    });
    setDailySeconds(current => current + sessionSeconds);

    if (pointsGained > 0) {
      const pointsData = { 
        totalPoints: increment(pointsGained), 
        lastUpdateTime: serverTimestamp() 
      };
      updateDoc(userDocRef, pointsData).catch(error => {
        errorEmitter.emit(
          'permission-error',
          new FirestorePermissionError({
            path: userDocRef.path,
            operation: 'update',
            requestResourceData: pointsData,
          })
        )
      });
      setTotalPoints(current => current + pointsGained);
    }

    toast({ title: "記録完了！", description: `${formatDuration(sessionSeconds)} の集中と ${pointsGained} ポイントを獲得しました。` });
    setSessionSeconds(0);

  }, [user, firestore, dailyRecordRef, userDocRef, sessionSeconds, toast]);


  useEffect(() => {
    if (!isRunning) return;

    const interval = setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          if (mode === 'study') {
            saveRecord();
            toast({ title: "✨ お疲れ様でした！", description: "少し休憩しましょう。" });
            setMode('break');
            return BREAK_TIME;
          } else {
            toast({ title: "☕ 休憩終了！", description: "集中する時間です。" });
            setMode('study');
            return STUDY_TIME;
          }
        }
        return prev - 1;
      });

      if (mode === 'study') {
        setSessionSeconds(s => s + 1);
      }

    }, 1000);

    return () => clearInterval(interval);
  }, [isRunning, mode, toast, saveRecord]);


  const handleMainButtonClick = () => {
    if (isRunning) {
        setIsRunning(false);
        if (user && sessionSeconds > 0) {
            saveRecord();
        }
        setSecondsLeft(STUDY_TIME);
        setMode('study');
        setSessionSeconds(0);

    } else {
        setIsRunning(true);
    }
  };

  const currentStreakSet = Math.floor(sessionSeconds / POINT_INCREMENT_INTERVAL);
  const nextBonus = 10 + currentStreakSet;

  return (
    <Card className="w-full max-w-lg mx-auto shadow-2xl border-primary/20">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="text-2xl font-bold">FocusFlow Timer</CardTitle>
          <div className="flex items-center gap-2">
          </div>
        </div>
      </CardHeader>
      <CardContent className="flex flex-col items-center">
        <div className="relative w-64 h-64 mb-6">
          <svg className="absolute top-0 left-0 w-full h-full" viewBox="0 0 200 200">
            <circle cx="100" cy="100" r={CIRCLE_RADIUS} fill="transparent" stroke="hsl(var(--muted))" strokeWidth="12" />
            <circle
              cx="100"
              cy="100"
              r={CIRCLE_RADIUS}
              fill="transparent"
              stroke={mode === 'study' ? "hsl(var(--primary))" : "hsl(var(--accent))"}
              strokeWidth="12"
              strokeDasharray={CIRCLE_CIRCUMFERENCE}
              strokeDashoffset={CIRCLE_CIRCUMFERENCE * (1 - progress)}
              strokeLinecap="round"
              transform="rotate(-90 100 100)"
              className="transition-all duration-1000 ease-linear"
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <div className="text-7xl font-mono font-bold text-white">{formatTime(secondsLeft)}</div>
            <div className="text-lg font-semibold text-muted-foreground">{mode === 'study' ? '集中' : '休憩中'}</div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 bg-background/50 p-4 rounded-xl mb-6 w-full">
            <div className="flex flex-col items-center border-r border-border pr-4">
                <span className="text-sm font-medium text-muted-foreground flex items-center gap-1"><Star className="h-4 w-4" /> 合計ポイント</span>
                <span className="text-3xl font-extrabold text-yellow-300">{isLoading ? <Skeleton className="h-8 w-24" /> : user ? totalPoints.toLocaleString() : '-'}</span>
            </div>
            <div className="flex flex-col items-center">
                <span className="text-sm font-medium text-muted-foreground flex items-center gap-1"><TimerIcon className="h-4 w-4" /> 今日の集中</span>
                <span className="text-3xl font-extrabold text-sky-400">{isLoading ? <Skeleton className="h-8 w-24" /> : formatDuration(dailySeconds)}</span>
            </div>
            {mode === 'study' && isRunning && user && (
              <div className="col-span-2 mt-2 pt-2 border-t border-border">
                  <span className="text-sm font-semibold text-green-400 text-center block">次のボーナス: +{nextBonus}P</span>
              </div>
            )}
        </div>


        <div className="flex space-x-4 mb-4">
          <Button size="lg" className="w-40" onClick={handleMainButtonClick}>
            {isRunning ? <Pause className="mr-2 h-5 w-5" /> : <Play className="mr-2 h-5 w-5" />}
            {isRunning ? '一時停止' : '記録'}
          </Button>
        </div>
         <Button variant="ghost" className="w-full" onClick={() => setIsHistoryModalOpen(true)} disabled={!user}>
          <History className="mr-2 h-4 w-4" />
          履歴を見る
        </Button>
      </CardContent>
      {user && <HistoryModal open={isHistoryModalOpen} onOpenChange={setIsHistoryModalOpen} />}
    </Card>
  );
}
