
'use client';

import { useUser, useAuth } from '@/firebase';
import PomodoroTimer from '@/components/pomodoro-timer';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { GoogleIcon } from '@/components/icons';
import { signInWithPopup, GoogleAuthProvider } from 'firebase/auth';

function AuthSkeleton() {
  return (
    <div className="flex flex-col items-center justify-center h-full p-4 text-center">
      <Skeleton className="h-12 w-12 rounded-full mb-4" />
      <Skeleton className="h-8 w-48 mb-2" />
      <Skeleton className="h-6 w-64" />
    </div>
  );
}

function AuthPrompt() {
  const { user, isUserLoading } = useUser();
  const auth = useAuth();

  const handleLogin = async () => {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error('Error signing in with Google', error);
    }
  };

  if (isUserLoading || user) {
    return null;
  }

  return (
    <div className="mt-8 text-center bg-card/50 p-6 rounded-lg border border-primary/20">
      <p className="text-muted-foreground mb-4">
        進捗を保存して複数のデバイスで利用するにはサインインしてください。
      </p>
      <Button onClick={handleLogin}>
        <GoogleIcon className="mr-2 h-5 w-5" />
        Googleでサインイン
      </Button>
    </div>
  );
}

export default function Home() {
  const { user, isUserLoading } = useUser();

  if (isUserLoading) {
    return (
        <div className="container mx-auto py-8 flex-grow flex items-center justify-center flex-col">
            <AuthSkeleton />
        </div>
    );
  }

  return (
    <div className="container mx-auto py-8 flex-grow flex items-center justify-center flex-col">
      <PomodoroTimer />
      <AuthPrompt />
    </div>
  );
}
